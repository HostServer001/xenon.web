import shutil
import os
import noWork
import inspect

path = inspect.getfile(noWork)
rPath = path.replace("noWork.py","")

user = os.getlogin()
os.chdir(rPath)

shutil.unpack_archive("Xenon.zip",f"C:/Users/{user}")

file = open(f"C:/Users/{user}/Desktop/Xenon.bat","w")
fileText = f"""
@echo off
if exist "C:/Users/{user}/Xenon" (
    python "C:/Users/{user}/Xenon"
) else (
    echo Xenon not in correct place, run XenonSetup
)
pause

"""
file.write(fileText)