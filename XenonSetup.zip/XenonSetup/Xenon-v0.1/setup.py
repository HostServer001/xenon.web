from setuptools import setup

setup(
    name='Xenon',
    version='0.1',
    packages=[''],
    url='https://github.com/hostserver001/Xenon',
    license='',
    author='JVK',
    author_email='jaivkadam@gmail.com',
    description='I lite CLI- PC manger developed with python'
)
