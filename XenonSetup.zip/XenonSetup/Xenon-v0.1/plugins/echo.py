def echo(text):
    print(text[5:])

