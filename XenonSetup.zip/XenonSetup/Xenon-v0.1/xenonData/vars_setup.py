import myInfo
import inspect
import os
import datetime

dataBasePath = inspect.getfile(myInfo).replace("myInfo.py","")

def newPath(path,fileName):
    path = os.path.join(path,fileName)
    return path

timeNow = f"{datetime.datetime.now().hour}:{datetime.datetime.now().minute}"