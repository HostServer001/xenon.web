import pyttsx3
import vars_setup
from xenonData import myInfo
import pickle


engine = pyttsx3.init()
engine.setProperty("rate",180)

def saveTempData(data):
    file = open(vars_setup.newPath(vars_setup.dataBasePath,'tempdata.tem'),"w")
    file.write(data)

def printAndSay(text):
    passw = True
    print(f"{vars_setup.DevInfo.assistantName(passw)}: {text}")
    if myInfo.speech == "on":
        engine.say(text)
        engine.runAndWait()
    else:
        pass

def loadAlias():
    file = open(vars_setup.newPath(vars_setup.dataBasePath,"alias.lock"),"rb")
    alias = pickle.load(file)
    file.close()
    return alias

def addAlias(aliasName,aliasContent,curretnAlias):
    curretnAlias[aliasName] = aliasContent
    file = open(vars_setup.newPath(vars_setup.dataBasePath,"alias.lock"),"wb")
    pickle.dump(curretnAlias,file)
    file.close()

def removeAlias(aliasName,currentAlias):
    currentAlias.pop(aliasName)
    file = open(vars_setup.newPath(vars_setup.dataBasePath,"alias.lock"),"wb")
    pickle.dump(currentAlias,file)
    file.close()

def listAlias(currentAlias):
    cnt = 0
    for i in currentAlias:
        print(f"Alias [{cnt}]: [{i}]")
        cnt += 1

def resetAlias(currentAlias):
    currentAlias.clear()
    file = open(vars_setup.newPath(vars_setup.dataBasePath,"alias.lock"),"wb")
    pickle.dump(currentAlias,file)
