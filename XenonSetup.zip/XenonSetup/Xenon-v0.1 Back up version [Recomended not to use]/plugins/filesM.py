import os
import funcs

def chage(user):
    userS = user.split(" ")
    try:
        num = int(userS[1])
        path = os.getcwd()
        listFiles = os.listdir(path)
        os.chdir(listFiles[num])
        funcs.printAndSay(f"Path changed to: {os.getcwd()}")
    except:
        os.chdir(user[5:])
        os.chdir(listFiles[num])
        funcs.printAndSay(f"Path changed to: {os.getcwd()}")
def back():
    os.chdir("..")