import pyautogui as gui
from . import myInfo

def leaveIt():
    wins = gui.getWindowsWithTitle(myInfo.title)
    wins[0].close()