import pyttsx3
import vars_setup
import myInfo

engine = pyttsx3.init()
engine.setProperty("rate",180)

def saveTempData(data):
    file = open(vars_setup.newPath(vars_setup.dataBasePath,'tempdata.tem'),"w")
    file.write(data)

def printAndSay(text):
    print(f"{vars_setup.DevInfo.assistantName(passw=True)}: {text}")
    if myInfo.speech == "on":
        engine.say(text)
        engine.runAndWait()
    else:
        pass

def alert(title,message):
    import tkinter

    wn = tkinter.Tk()
    wn.geometry("300x100")
    wn.title(title)

    text = tkinter.Label(
        wn,
        text=message,
        pady=25
    )
    close = tkinter.Button(
        wn,
        text="Close",
        command=wn.destroy,
        height=1,
        width=10
    )

    text.pack()
    close.pack()

    wn.mainloop()